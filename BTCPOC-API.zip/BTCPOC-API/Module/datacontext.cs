﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BTCPOC_API.viewModel;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration;

namespace BTCPOC_API.Module
{
    public class datacontext : IRepoDataAccess

    {
       
        public ExcelDataObj GetDataById(int id)
        {
            throw new NotImplementedException();
        }

        public ExcelDataObj GetExceldata(int id)
        {
            throw new NotImplementedException();
        }

        public List<Reportlist> GetReportList()
        {
            throw new NotImplementedException();
        }

        public string UpdateData(ExcelDataObj Exldat)
        {
            throw new NotImplementedException();
        }

        public int UpdateExcelData(ExcelDataObj Exldat)
        {
            throw new NotImplementedException();
        }
    }
}
