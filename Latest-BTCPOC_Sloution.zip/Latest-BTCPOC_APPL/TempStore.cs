﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Latest_BTCPOC_APPL
{
    public class TempStore
    {
      
        public DateTime Date { get; set; }

        public int Id { get; set; }

        public string ExcelFile =>  (string)("Sanjeeva Shrivastava");

        public string excel { get; set; }
    }
}
