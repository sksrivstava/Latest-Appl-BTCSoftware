import { combineReducers } from "redux";
import { rtemplate } from "./Rtemplate";
export const reducers = combineReducers({
    rtemplate
});
