/* const initialstate = {
  employees: [
    { id: 1, employeeName: "Employee 1", employeeDepartment: ".NET Team" },
    { id: 2, employeeName: "Employee 2", employeeDepartment: "Mobile Team" },
    { id: 3, employeeName: "Employee 3", employeeDepartment: "Design Team" },
  ],
}; */

const initialstate = {
    Templates: [],
  };
  const TempReducer = (state = initialstate, action) => {
    switch (action.type) {
      case "GET_Template":
        return {
          ...state,
          Templates: [...action.payload],
        };
      case "ADD_Template":
        return {
          ...state,
          Templates: [...state.Templates, action.payload],
        };
      case "EDIT_Template":
        return {
          ...state,
          Templates: state.Templates.map((content, i) =>
            content.id === action.payload.id
              ? {
                  ...content,
                  TemplateName: action.payload.TemplateName,
                  id: action.payload.employeeDepartment,
                }
              : content
          ),
        };
      case "DELETE_Template":
        return {
          ...state,
          Templates: state.Templates.filter((item) => item.id !== action.payload),
        };
      default:
        return state;
    }
  };
  
  export default TempReducer;
  