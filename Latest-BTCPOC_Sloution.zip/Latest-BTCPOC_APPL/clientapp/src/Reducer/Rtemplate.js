﻿import { ACTION_TYPES } from "../action/Dtemplate";

const initialstate = {
    list: []
     
}

export const rtemplate = (state=initialstate, action)=> {
    switch (action.type) {
        case ACTION_TYPES.LIST:
            return {
                ...state,
                list: [...action.payload],
            };
        case ACTION_TYPES.OPEN:
            return {
                ...state,
                list: [...state.list, action.payload],
            };
        case ACTION_TYPES.UPDATE:
            return {
                ...state,
                list: state.list.map((content, i) =>
                    content.id === action.payload.id
                        ? {
                            ...content,
                            excelName: action.payload.excelName,
                            excel: action.payload.excel,
                        }
                        : content
                ),
            };
        case ACTION_TYPES.DELETE:
            return {
                ...state,
                list: state.list.filter((item) => item.id !== action.payload),
            };
        default:
            return state;
    }
}
