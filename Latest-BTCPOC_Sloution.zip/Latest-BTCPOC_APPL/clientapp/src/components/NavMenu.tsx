import  React, { Component, useState } from "react";
import { Collapse, Container, Navbar, NavbarBrand, NavbarToggler, NavItem, NavLink } from 'reactstrap';
import { Link } from 'react-router-dom';
import './NavMenu.css';


var sheetProct = {
    repodata: [] 

};

export default class NavMenu extends React.PureComponent<{}, { isOpen: boolean}> {
       public state = {
        isOpen: false,
       
    };
    report = { };

    //componentDidMount() {

    //    fetch('http://localhost:62271/api/ExlData/')
    //        .then(res => res.json())
    //        .then((res) => {
    //            console.log(res);
    //            //this.setState({ Repodata: res.data.slice(0, 10) });
    //            //debugger;
    //            sheetProct = {
    //                ...sheetProct, repodata: res
    //            }
               

    //        })
    //        .catch(error => {
    //            console.error('There has been a problem with your fetch operation:', error);
    //        });
    //};


    public render() {
        return (
            <header>
                <Navbar className="navbar-expand-sm navbar-toggleable-sm border-bottom box-shadow mb-3" light>
                    <Container>
                        <NavbarBrand tag={Link} to="/">Account Production</NavbarBrand>
                        <NavbarToggler onClick={this.toggle} className="mr-2"/>
                        <Collapse className="d-sm-inline-flex flex-sm-row-reverse" isOpen={this.state.isOpen} navbar>
                            <ul className="navbar-nav flex-grow">
                                <NavItem>
                                    <NavLink tag={Link} className="text-dark" to="/">Home</NavLink>
                                </NavItem>
                              <NavItem>
                                    <NavLink tag={Link} className="text-dark" to="/Spreadsheet">Spread Sheet</NavLink>
                                </NavItem>
                                <NavItem>
                                    <NavLink tag={Link} className="text-dark" to="/Template">Template</NavLink>
                                </NavItem> 
                               
                         </ul>
                        </Collapse>
                    </Container>
                </Navbar>
            </header>
        );
    }

    private toggle = () => {
        this.setState({
            isOpen: !this.state.isOpen
        });
    }
}
