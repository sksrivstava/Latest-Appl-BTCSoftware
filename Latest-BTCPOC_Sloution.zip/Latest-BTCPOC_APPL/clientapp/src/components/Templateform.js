﻿import React, {useState, useEffect} from "react";
//import * as ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import * as actions from '../action/Dtemplate';
import { rtemplate } from "../Reducer/Rtemplate";

/* import { ConnectedRouter } from 'connected-react-router';
import { createBrowserHistory } from 'history';
 *///import { Store } from "./Action/Store";
//import * from "../Action/Dtemplate";


const Templateform = (prpos) => {
    useEffect(()=>{
        prpos.fetchallTemplate()
    },[]) // worked as componentdidmount

    return (<div>from sanjeeva</div>)
}
const mapStateToProps = state => ({
     Templatelist: state.rtemplate.list })

     const mapActionToProps={
         fetchallTemplate: actions.fetchall
     }
export default connect(mapStateToProps,mapActionToProps)( Templateform);