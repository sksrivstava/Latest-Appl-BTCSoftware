//import 'bootstrap.css';
import '@grapecity/wijmo.styles/wijmo.css';
import * as ReactDOM from 'react-dom';
import { DefinedName } from '@grapecity/wijmo.grid.sheet';
import React, { Component, useState } from "react";
import * as wijmo from '@grapecity/wijmo';
import * as wjGridSheet from "@grapecity/wijmo.react.grid.sheet";
import * as wjInput from '@grapecity/wijmo.react.input';
import * as wjcXlsx from '@grapecity/wijmo.xlsx';
import "@grapecity/wijmo.grid.xlsx";
import './Sheet.css';

var sheetProct = {
    sh1: false,
    sh2: false,
    sh3: false

};

var Rdata = {
    List: null
};
  
export default class Spreadsheet extends React.Component {
    constructor(props) {
        super(props);
        this._applyFillColor = false;
        this.ref = React.createRef();
        data: this.getData(10);
        this.menu = React.createRef();
        this.defNameBox = React.createRef();
        
        //this.gridRef = React.createRef();
        //this.menuItemClicked = this.menuItemClicked.bind(this);

       
        //
        this._fonts = [
            { name: 'Arial', value: 'Arial, Helvetica, sans-serif' },
            { name: 'Arial Black', value: '"Arial Black", Gadget, sans-serif' },
            { name: 'Comic Sans MS', value: '"Comic Sans MS", cursive, sans-serif' },
            { name: 'Courier New', value: '"Courier New", Courier, monospace' },
            { name: 'Georgia', value: 'Georgia, serif' },
            { name: 'Impact', value: 'Impact, Charcoal, sans-serif' },
            { name: 'Lucida Console', value: '"Lucida Console", Monaco, monospace' },
            { name: 'Lucida Sans Unicode', value: '"Lucida Sans Unicode", "Lucida Grande", sans-serif' },
            { name: 'Palatino Linotype', value: '"Palatino Linotype", "Book Antiqua", Palatino, serif' },
            { name: 'Tahoma', value: 'Tahoma, Geneva, sans-serif' },
            { name: 'Segoe UI', value: '"Segoe UI", "Roboto", sans-serif' },
            { name: 'Times New Roman', value: '"Times New Roman", Times, serif' },
            { name: 'Trebuchet MS', value: '"Trebuchet MS", Helvetica, sans-serif' },
            { name: 'Verdana', value: 'Verdana, Geneva, sans-serif' }
        ];
        //
        this._fontSizeList = [
            { name: '8', value: '8px' },
            { name: '9', value: '9px' },
            { name: '10', value: '10px' },
            { name: '11', value: '11px' },
            { name: '12', value: '12px' },
            { name: '14', value: '14px' },
            { name: '16', value: '16px' },
            { name: '18', value: '18px' },
            { name: '20', value: '20px' },
            { name: '22', value: '22px' },
            { name: '24', value: '24px' }
        ];
        this._updatingSelection = false;
        //

        // merge cell
        this.mergeCells = () => {
            this.state.flex.mergeRange();
            this.setState(this.state.flex.getSelectionFormatState());
        };
        //merge block end

        this.state = {
            selectedValue: '0',
            fontIdx: 0,
            fontSizeIdx: 5,
            isBold: false,
            isItalic: false,
            isUnderline: false,
            textAlign: 'left',
            fileName: "",
            flex: null,
            blob: null,
            currentSheetOnly: false,
            repodata: [],
            selectedrep: '0',
            sheetdata: [],
            selectsht: '0',
            secctiondata: []
        };
           
        //this.sh1 = { Name: "", val: false };
        //this.sh2 = { Name: "", val: false };
        //this.sh3 = { Name: "", val: false };

    }
   
      
    addDefName() {
        
    var sheet = this.state.flex;
    var defName = this.defNameBox.current.control.text;
        if (wijmo.isEmpty(defName)) {
      alert('Name not defined!');
    }
    var sheetName = this.state.currentSheetOnly ? sheet.selectedSheet.name : undefined;
        var namedRng = this.getNamedRange(sheet.selection);
        //debugger;
        var defName = new DefinedName(sheet, defName, namedRng, sheetName);
        //debugger;
        sheet.definedNames.push(defName);
        this.setState({ secctiondata: sheet.definedNames });
       
    }
    getDefinedNameValue(selection, name) {
        var rng = this.getNamedRange(selection);
        var sheetName = `'${name}'!`;
        return sheetName + rng;
    }

    getNamedRange(selection) {
        var { topRow, leftCol } = selection;
        var { bottomRow, rightCol } = selection;
        var rng1 = wjcXlsx.Workbook.xlsxAddress(topRow, leftCol);
        var rng2 = wjcXlsx.Workbook.xlsxAddress(bottomRow, rightCol);
        if (selection.isSingleCell) {
            return rng1;
        }
        return `${rng1}:${rng2}`;
    }
  
    getData(count) {
        // create some random data
        var countries = "US,Germany,UK,Japan,Italy,Greece".split(","),
            data = [];
        for (var i = 0; i < count; i++) {
            var condition = Boolean(Math.floor(Math.random() + 0.5));
            data.push({
                id: i,
                country: countries[i % countries.length],
                downloads: Math.random() * 100000,
                mixed: condition
                    ? ""
                    : countries[Math.floor(Math.random() * countries.length)],
                checked: condition
            });
        }
        return data;
    }


    Convt_html = () => {
        //debugger;
        const element = document.createElement("a");
        var file = document.getElementById('Grid_Cont').innerHTML;

        //var file = document.getElementsByClassName('wj-cells'); //.innerHTML;  //wj - cells').innerHTML;

        //var file = new Blob([document.getElementById('Grid_Cont').innerHTML], { type: 'text/plain' });
        console.log(file);

        var htmlstr = '<!DOCTYPE html> <html lang="en">';
        htmlstr = htmlstr + '<head><meta charset="utf-8">';
        htmlstr = htmlstr + '<meta http-equiv="X-UA-Compatible" content="IE=edge">';
        htmlstr = htmlstr + '<link type="text/css" rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">';
        htmlstr = htmlstr + '<link type="text/css" rel="stylesheet" href="https://cdn.grapecity.com/wijmo/5.latest/styles/wijmo.min.css" data-systemjs-css="">';
        htmlstr = htmlstr + '<style> .container-fluid .wj-flexsheet {height: 400px;margin: 6px 0;}';
        htmlstr = htmlstr + '</style></head><body>";';
        htmlstr = htmlstr + file;
        htmlstr = htmlstr + '</body>';
        console.log(htmlstr);

        //debugger;
        var myBlob = new Blob([htmlstr], { type: 'text/html' });

        element.href = URL.createObjectURL(myBlob);
        element.download = "myFile.HTML";
        document.body.appendChild(element); // Required for this to work in FireFox
        element.click();
    }

    onSelectedSheetChanged(s, e) {
        //debugger;
        var sheet = s.selectedSheet;
        
        if (sheet.name  == "Sheet1") {
            s.isReadOnly = sheetProct.sh1;
        }
        if (sheet.name  == "Sheet2") {
            s.isReadOnly = sheetProct.sh2;
        }
        if (sheet.name == "Sheet3") {
            s.isReadOnly = sheetProct.sh3;
        }
        // s is flexSheet
        // check if the sheet is read-only
        // then set the isReadOnly property
        //sheet.isReadOnly = sheet.isReadOnly;
        //if (sheet.name == 'Sheet3') {
        //    s.isReadOnly = true;
        //}
        //else {
        //    s.isReadOnly = false;


        //}
    }
    componentDidMount() {
       
        fetch('http://localhost:62271/api/ExlData/')
            .then(res => res.json())
            .then((res) => {
                console.log(res);
                //this.setState({ Repodata: res.data.slice(0, 10) });
                //debugger;
                this.setState({ repodata: res });
                console.log(this.state.repodata);
                
                
            })
            .catch(error => {
                console.error('There has been a problem with your fetch operation:', error);
            });
    };

    render() {
        
        return (<div className="container-fluid" >
            <div>
            <p>Select a range and add it to the defined name</p>
      DefinedName: <wjInput.ComboBox ref={this.defNameBox} />&nbsp;&nbsp;
            <button onClick={this.addDefName.bind(this)}>Add</button>&nbsp;&nbsp;
            <input type="checkbox" checked={this.state.currentSheetOnly} onChange={(e) =>
                    this.setState({ currentSheetOnly: e.target.checked })} /> Add for current sheet only
            <br /><br />

                <div className="well well-lg">
                    <wjInput.Menu header='Select Report File' value={this.state.selectedrep} itemClicked={this.DisplayReport.bind(this)}>
                        {this.state.repodata.map(listitem => (
                        <wjInput.MenuItem value={listitem.id}>{listitem.excelName}</wjInput.MenuItem>

                        ))}
                        
                    </wjInput.Menu>
                    <wjInput.Menu header='Select Sheets' value={this.state.selectsht}
                        itemClicked={this.DisplaySheet.bind(this)}>
                        {this.state.sheetdata.map(listitem => (
                            <wjInput.MenuItem
                                value={listitem}>{listitem}</wjInput.MenuItem>

                        ))}

                    </wjInput.Menu>
                    <wjInput.Menu header='Select Section' value={"0"}
                        itemClicked={this.DisplaySheet.bind(this)}>
                        {this.state.secctiondata.map(listitem => (
                            <wjInput.MenuItem
                                value={listitem._name}>{listitem._name}</wjInput.MenuItem>

                        ))}

                    </wjInput.Menu>

                </div>
                
            </div>
            <wjInput.Menu
                header="Context Menu"
                selectedValuePath="cmd"
                dropDownCssClass="ctx-menu"
                style={{ display: 'none' }}
                ref={this.menu}
            >
                <wjInput.MenuItem cmd="cmdNew">
                    <span className="glyphicon glyphicon-asterisk" />&nbsp;&nbsp;New
          </wjInput.MenuItem>
                <wjInput.MenuItem cmd="cmdOpen">
                    <span className="glyphicon glyphicon-folder-open" />&nbsp;&nbsp;Open
          </wjInput.MenuItem>
                <wjInput.MenuItem cmd="cmdSave">
                    <span className="glyphicon glyphicon-floppy-disk" />&nbsp;&nbsp;Save
          </wjInput.MenuItem>
                <wjInput.MenuSeparator />
                <wjInput.MenuItem cmd="cmdExit">
                    <span className="glyphicon glyphicon-remove" />&nbsp;&nbsp;Exit
          </wjInput.MenuItem>
            </wjInput.Menu>
            <wjGridSheet.FlexSheet initialized={this.initializeFlexSheet.bind(this)} id="Grid_Cont"
                ref={this.gridRef} className="has-ctx-menu" 
                selectedSheetChanged={this.onSelectedSheetChanged.bind(this)}
                allowSorting={false} Gridlines={false} 
            >

            </wjGridSheet.FlexSheet>

            <button onClick={() => console.log(this.state.flex.definedNames)}>Show all Defined Names</button>
     
          
            <wjInput.ColorPicker style={{ display: "none", position: "fixed", zIndex: 100 }}
                initialized={this.colorPickerInit.bind(this)}>
            </wjInput.ColorPicker>
            <div className="well well-lg">
                <wjInput.Menu header='Format' value={this.state.selectedValue} itemClicked={this.formatChanged.bind(this)}>
                    <wjInput.MenuItem value="0">Decimal Format</wjInput.MenuItem>
                    <wjInput.MenuItem value="n2">Number Format</wjInput.MenuItem>
                    <wjInput.MenuItem value="p">Percentage Format</wjInput.MenuItem>
                    <wjInput.MenuItem value="c2">Currency Format</wjInput.MenuItem>
                    <wjInput.MenuSeparator></wjInput.MenuSeparator>
                    <wjInput.MenuItem value="d">Short Date</wjInput.MenuItem>
                    <wjInput.MenuItem value="D">Long Date</wjInput.MenuItem>
                    <wjInput.MenuItem value="f">Full Date/TIme (short time)</wjInput.MenuItem>
                    <wjInput.MenuItem value="F">Full Date/TIme (long time)</wjInput.MenuItem>
                </wjInput.Menu>
                <div>Font:
                        <wjInput.ComboBox style={{ width: "120px" }} itemsSource={this._fonts} selectedIndex={this.state.fontIdx} displayMemberPath="name" selectedValuePath="value" isEditable={false} selectedIndexChanged={this.fontChanged.bind(this)}>
                    </wjInput.ComboBox>
                    <wjInput.ComboBox style={{ width: "80px" }} itemsSource={this._fontSizeList} selectedIndex={this.state.fontSizeIdx} displayMemberPath="name" selectedValuePath="value" isEditable={false} selectedIndexChanged={this.fontSizeChanged.bind(this)}>
                    </wjInput.ComboBox>
                    <div className="btn-group">
                        <button type="button" className={`btn btn-default ${this.state.isBold ? 'active' : ''}`} onClick={this.applyBoldStyle.bind(this)}>
                            Bold</button>
                        <button type="button" className={`btn btn-default ${this.state.isItalic ? 'active' : ''}`} onClick={this.applyItalicStyle.bind(this)}>
                            Italic</button>
                        <button type="button" className={`btn btn-default ${this.state.isUnderline ? 'active' : ''}`} onClick={this.applyUnderlineStyle.bind(this)}>
                            Underline</button>
                    </div>
                </div>
                <div>Color:
                        <div className="btn-group">
                        <button type="button" className="btn btn-default" onClick={(e) => this.showColorPicker(e, false)}>
                            Fore Color</button>
                        <button type="button" className="btn btn-default" onClick={(e) => this.showColorPicker(e, true)}>
                            Fill Color</button>
                    </div>Alignment:
                        <div className="btn-group">
                        <button type="button" className={`btn btn-default ${this.state.textAlign == 'left' ? 'active' : ''}`} onClick={() => this.applyCellTextAlign("left")}>
                            Left</button>
                        <button type="button" className={`btn btn-default ${this.state.textAlign == 'center' ? 'active' : ''}`} onClick={() => this.applyCellTextAlign("center")}>
                            Center</button>
                        <button type="button" className={`btn btn-default ${this.state.textAlign == 'right' ? 'active' : ''}`} onClick={() => this.applyCellTextAlign("right")}>
                            Right</button>
                    </div>
                </div>
            </div>
            <div className="form-inline well well-lg">
                <button onClick={this.mergeCells.bind(this)} type="button" className="btn btn-default">
                    {this.state.isMergedCell ? 'UnMerge' : 'Merge'}
                </button>
                <button type="button" className={`btn btn-default`} onClick={() => this.Convt_html()}>
                    Convert To HTML</button>
                <button type="button" className={`btn btn-default`} onClick={() => this.ChangeCellvalue("Sanjeeva")}>
                    Replace Cell Value  </button>
                <button onClick={() => this.addBoundSheet()}>Add Bound Sheet</button>
                <button onClick={() => this.addUnboundSheet()}>Add Unbound Sheet</button>


               <button type="button" className={`btn btn-default`} onClick={() => this.prtGrid(this.state.flex.selectedSheet)}>
                    protect Sheet</button>

                <button type="button" className={`btn btn-default`} onClick={() => this.HideRow(this)}>
                    Hide Row</button>
                <button type="button" className={`btn btn-default`} onClick={() => this.HideColumn(this)}>
                    Hide Column</button>
                <button type="button" className={`btn btn-default`} onClick={() => this.unhideAll(this)}>
                    UnHide All</button>

                <button type="button" className={`btn btn-default`} onClick={() => this.InsRow(this)}>
                    Insert row</button>
                <button type="button" className={`btn btn-default`} onClick={() => this.InsCol(this)}>
                    Insert Column</button>

                <button type="button" className={`btn btn-default`} onClick={() => this.applycellName(this)}>
                    Assign Name</button>
                

            </div>
            <div className="form-inline well well-lg">
              
                <input type="file" className="form-control" id="importFile" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" />
                <button className="btn btn-default" onClick={this.load.bind(this)}>Load</button>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                File Name:
                <input type="text" className="form-control" onChange={this.setFileName.bind(this)} value={this.state.fileName} />
                <button className="btn btn-default" onClick={this.save.bind(this)}>Save</button>
            </div>



        </div>);
    }

    menuItemClicked(sender) {
        alert('Executing **' + sender.selectedValue + '** for element **' + sender.owner.id + '**');
    }


  
    LoadExcelFile(flex) {
        //debugger;
      //  flex.wjGrid.Menu =FlexGridContextMenu;
           flex.deferUpdate(() => {
            if (flex) {
                fetch('http://localhost:3000/api/open/Sample.xlsx')
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.blob();
                    })
                    .then(myBlob => {
                        this.setState({ fileName: 'Sample.xlsx' })
                        this.setState({ blob: myBlob })
                        this.state.flex.loadAsync(myBlob);
                    })
                    .catch(error => {
                        console.error('There has been a problem with your fetch operation:', error);
                    });

                flex.selectedSheetIndex = 0;

                setTimeout(() => this._updateSelection(flex, flex.selection), 100);
            }
           });
        //debugger;
        var menu = this.menu.current.control;
        flex.hostElement.addEventListener('contextmenu', e => {
            // prevent opening the default menu
            e.preventDefault();
            e.stopPropagation();
            menu.show(e); // display the custom menu
        }, true);

          flex.selectionChanged.addHandler((flex, args) => {
            this._updateSelection(flex, args.range);
        });

        //merge cell
        flex.selectionChanged.addHandler(() => {
            this.setState(flex.getSelectionFormatState());
        });
        //merge cell end

        this.setState({
            flex: flex
        });
    }

    DisplayReport(id) {
        //debugger;
        this.setState({ selectedrep: id.selectedValue });
        fetch('http://localhost:62271/api/ExlData/' + id.selectedValue)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                //debugger;
                return response.blob();
            })
            .then(myBlob => {
                //debugger;
                this.state.flex.loadAsync(myBlob, (loaded) => {
                    var sheets = loaded.sheets.length;
                    console.log(sheets); // number of sheets
                    var names = loaded.sheets.map(s => s.name);
                    this.setState({ sheetdata: names });
                    this.setState({ selectsht: names[0] });
                  //  this.setState({ secctiondata: s.definedNames });


                    console.log(names); // number of names
                });
               // this.state.flex.loadAsync(myBlob)
            })
            .catch(error => {
                console.error('There has been a problem with your fetch operation:', error);
            });

    }
    initializeFlexSheet(flex,id) {
        flex.deferUpdate(() => {
            id = 1;
            //if (this.state.flex) { 
            //api block 
            //debugger;
            fetch('http://localhost:62271/api/ExlData/1')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    //debugger;
                    return response.blob();
                })
                .then(myBlob => {
                    //debugger;
                    this.state.flex.loadAsync(myBlob, (loaded) => {
                        var sheets = loaded.sheets.length;
                        var names = loaded.sheets.map(s => s.name);
                        this.setState({ sheetdata: names });
                        this.setState({ selectsht: names[0] });
                     //   this.setState({ secctiondata: loaded.sheet.definedNames });

                        
                    });
                    
                })
                .catch(error => {
                    console.error('There has been a problem with your fetch operation:', error);
                });
            //api block end
            //}
        });
        var menu = this.menu.current.control;
        flex.hostElement.addEventListener('contextmenu', e => {
            // prevent opening the default menu
            e.preventDefault();
            e.stopPropagation();
            menu.show(e); // display the custom menu
        }, true);
        flex.selectionChanged.addHandler((flex, args) => {
            this._updateSelection(flex, args.range);
        });

        //merge cell
        flex.selectionChanged.addHandler(() => {
            this.setState(flex.getSelectionFormatState());
        });

        this.setState({
            flex: flex
        });
    }

    // Load xlsx file to FlexSheet.
      fontChanged(flex) {
        if (flex.selectedItem && !this._updatingSelection) {
            this.state.flex.applyCellsStyle({ fontFamily: flex.selectedItem.value });
        }
    }
    //
    fontSizeChanged(flex) {
        if (flex.selectedItem && !this._updatingSelection) {
            this.state.flex.applyCellsStyle({ fontSize: flex.selectedItem.value });
        }
    }
    //
    colorPickerInit(flex) {
        let blurEvt = /firefox/i.test(window.navigator.userAgent) ? 'blur' : 'focusout';
        flex.hostElement.addEventListener(blurEvt, () => {
            setTimeout(() => {
                if (!flex.containsFocus()) {
                    this._updatingSelection = false;
                    flex.hostElement.style.display = 'none';
                }
            }, 0);
        });
        //
        // Initialize the value changed event handler for the color picker control.
        flex.valueChanged.addHandler(() => {
            if (this._applyFillColor) {
                this.state.flex.applyCellsStyle({ backgroundColor: flex.value });
            }
            else {
                this.state.flex.applyCellsStyle({ color: flex.value });
            }
        });
        //
        this._colorPicker = flex;
    }

    formatChanged(flex) {
        if (flex.selectedValue) {
            this.state.flex.applyCellsStyle({ format: flex.selectedValue });
            this.setState({ selectedValue: flex.selectedValue });
        }
    }
    //
    // apply the text alignment for the selected cells
    applyCellTextAlign(value) {
        //debugger;
        this.state.flex.applyCellsStyle({ textAlign: value });
        this.setState({ textAlign: value });

    }
    ChangeCellvalue(val) {
        //debugger;
        this.state.flex.activeCell.innerHTML = val;
        this.setState({ flex: this.state.flex });


    }
    DisplaySheet(val) {

        this.state.flex.selectedSheetIndex = val.selectedIndex;
        this.setState({ selectsht: val.selectedItem.text });



    }
    ChangeSheet(value) {
        //debugger;

        this.state.flex.selectedSheetIndex = value;


    }

    addBoundSheet() {
        var sheet = this.state.flex;
        var data = this.getData(10);
        // data is the data to be bound to the sheet
        sheet.addBoundSheet('Sheet ' + sheet.sheets.length, data);
        var names = sheet.sheets.map(s => s.name);
        this.setState({ sheetdata: names });
        
    }

    addUnboundSheet() {
        var sheet = this.state.flex;
        // 10 and 15 is the number of rows and columns respectively
        // you do not need to provide them if they are not known
        sheet.addUnboundSheet('Sheet ' + sheet.sheets.length, 10, 15);
        var names = sheet.sheets.map(s => s.name);

        this.setState({ sheetdata: names });
    }

  
    /* Prtcell() {
        //debugger;
        this.state.flex.selectedSheet.grid.rows[rowIdx].readonly = true;
      //  this.state.flex.selectedSheet.isReadOnly = !this.state.flex.selectedSheet.isReadOnly;
       /// this.setState({ ...state, flex: this.state.flex });

    } */
    prtGrid() {

        //debugger;
       // this.state.flex.selectedSheet.isReadOnly = !this.state.flex.selectedSheet.isReadOnly;
        if (this.state.flex.selectedSheetIndex == 0) {
            sheetProct = {
                ...sheetProct, sh1: !sheetProct.sh1
            };
          // this.setState({ sh1: !this.state.sh1 });
        }
        if (this.state.flex.selectedSheetIndex == 1) {
            //this.state=   this.setState({sh2: !this.state.sh2});
            sheetProct = {
                ...sheetProct, sh2: !sheetProct.sh2
            };
        }
        if (this.state.flex.selectedSheetIndex == 2) {
            //this.state =   this.setState({sh3: !this.state.sh3 });
            sheetProct= {
                ...sheetProct, sh3: !sheetProct.sh3
            };
        }
        this.state.flex.onSelectedSheetChanged(this.state.flex);

        //// s is flexSheet
        //// check if the sheet is read-only
        //// then set the isReadOnly property
        //if (sheet.name == 'Sheet3') {
       // sheet.isReadOnly = true;
        //}
        //else {
        //    s.isReadOnly = false;
        //}
        //this.state.flex.selectedSheet.isReadOnly = true;
       
    }

    ProtectSheet(e) {
        //debugger;
        this.state.flex.isReadOnly = !this.state.flex.isReadOnly;
        //<button type="button" className={`btn btn-default`} onClick={() => this.ProtectSheet(this)}>
        //    protect All Sheet</button>
    }
    HideColumn() {
        //debugger;
        var colIdx = this.state.flex.selection.col;

        this.state.flex.selectedSheet.grid.columns[colIdx].visible = !this.state.flex.selectedSheet.grid.columns[colIdx].visible;

        }
    InsRow() {
        //debugger;
        var rowIdx = this.state.flex.selection.row;
        this.state.flex.insertRows(rowIdx, 1);
    }
    InsCol() {
        //debugger;
        var colIdx = this.state.flex.selection.col;
        this.state.flex.insertColumns(colIdx, 1);

        //   var rowIdx = this.state.flex.selection.row';
        //this.state.flex.selectedSheet.grid.Rows.ins

    }
    unhideAll() {
        //debugger;
      //  var rowIdx = this.state.flex.selection.row;
        //this.state.flex.selectedSheet.grid.rows[rowIdx].visible = !this.state.flex.selectedSheet.grid.rows[rowIdx].visible;
        for (var i = 0; i < this.state.flex.selectedSheet.grid.rows.length; i++) {
            this.state.flex.selectedSheet.grid.rows[i].visible = true;
        }
     //   var colIdx = this.state.flex.selection.col;
        for (var i = 0; i < this.state.flex.selectedSheet.grid.columns.length; i++) {
            this.state.flex.selectedSheet.grid.columns[i].visible = true;
        }

    }
    HideRow(e) {
        //debugger;
        var rowIdx = this.state.flex.selection.row;
        this.state.flex.selectedSheet.grid.rows[rowIdx].visible = !this.state.flex.selectedSheet.grid.rows[rowIdx].visible;
      //  this.state.flex.activeCell.hidden = !this.state.flex.activeCell.hidden;
  
    }
    applycellName() {
        //debugger;
        this.state.flex.name = "test1";
    }

    //
    // apply the bold font weight for the selected cells
    applyBoldStyle() {
        this.state.flex.applyCellsStyle({ fontWeight: this.state.isBold ? 'none' : 'bold' });
        this.setState({ isBold: !this.state.isBold });
    }
    //
    // apply the underline text decoration for the selected cells
    applyUnderlineStyle() {
        this.state.flex.applyCellsStyle({ textDecoration: this.state.isUnderline ? 'none' : 'underline' });
        this.setState({ isUnderline: !this.state.isUnderline });
    }
    //
    // apply the italic font style for the selected cells
    applyItalicStyle() {
        this.state.flex.applyCellsStyle({ fontStyle: this.state.isItalic ? 'none' : 'italic' });
        this.setState({ isItalic: !this.state.isItalic });
    }
    //
    // show the color picker control.
    showColorPicker(e, isFillColor) {
        let offset = this._cumulativeOffset(e.target);
        //
        let he = this._colorPicker.hostElement;
        he.style.display = 'inline';
        he.style.left = offset.left + 'px';
        he.style.top = offset.top - he.clientHeight - 5 + 'px';
        he.focus();
        //
        this._applyFillColor = isFillColor;
    }

    _updateSelection(fs, sel) {
        let rCnt = fs.rows.length, cCnt = fs.columns.length, fontIdx = 0, fontSizeIdx = 5;
        //
        this._updatingSelection = true;
        //
        if (sel.row > -1 && sel.col > -1 && rCnt > 0 && cCnt > 0 && sel.col < cCnt && sel.col2 < cCnt && sel.row < rCnt && sel.row2 < rCnt) {
            let cellContent = fs.getCellData(sel.row, sel.col, false), cellStyle = fs.selectedSheet.getCellStyle(sel.row, sel.col), cellFormat;
            //
            if (cellStyle) {
                fontIdx = this._checkFontfamily(cellStyle.fontFamily);
                fontSizeIdx = this._checkFontSize(cellStyle.fontSize);
                cellFormat = cellStyle.format;
            }
            //
            let format;
            if (!!cellFormat) {
                format = cellFormat;
            }
            else {
                if (wijmo.isInt(cellContent)) {
                    format = '0';
                }
                else if (wijmo.isNumber(cellContent)) {
                    format = 'n2';
                }
                else if (wijmo.isDate(cellContent)) {
                    format = 'd';
                }
            }
            //
            let state = fs.getSelectionFormatState();
            this.setState({
                isBold: state.isBold,
                isItalic: state.isItalic,
                isUnderline: state.isUnderline,
                textAlign: state.textAlign,
                fontIdx: fontIdx,
                fontSizeIdx: fontSizeIdx
            });
        }
        //
        this._updatingSelection = false;
    }

    // check font family for the font name combobox of the ribbon.
    _checkFontfamily(value) {
        let fonts = this._fonts;
        //
        if (!value) {
            return 0;
        }
        //
        for (let fontIndex = 0; fontIndex < fonts.length; fontIndex++) {
            let font = fonts[fontIndex];
            if (font.name === value || font.value === value) {
                return fontIndex;
            }
        }
        //
        return 0;
    }
    //
    // check font size for the font size combobox of the ribbon.
    _checkFontSize(value) {
        let sizeList = this._fontSizeList;
        //
        if (value == null) {
            return 5;
        }
        //
        for (let index = 0; index < sizeList.length; index++) {
            let size = sizeList[index];
            if (size.value === value || size.name === value) {
                return index;
            }
        }
        //
        return 5;
    }
    //
    // Get the absolute position of the dom element.
    _cumulativeOffset(element) {
        let top = 0, left = 0, scrollTop = 0, scrollLeft = 0;
        //
        do {
            top += element.offsetTop || 0;
            left += element.offsetLeft || 0;
            scrollTop += element.scrollTop || 0;
            scrollLeft += element.scrollLeft || 0;
            element = element.offsetParent;
        } while (element && !(element instanceof HTMLBodyElement));
        //
        scrollTop += document.body.scrollTop || document.documentElement.scrollTop;
        scrollLeft += document.body.scrollLeft || document.documentElement.scrollLeft;
        //
        return {
            top: top - scrollTop,
            left: left - scrollLeft
        };
    }
    
    load() {
        let fileInput = document.getElementById("importFile");

        if (this.state.flex && fileInput.files[0]) {
            this.state.flex.loadAsync(fileInput.files[0], (loaded) => {
                var sheets = loaded.sheets.length;
                var names = loaded.sheets.map(s => s.name);
                this.setState({ sheetdata: names });
                this.setState({ selectsht: names[0] });
               // this.setState({ secctiondata: loaded.sheet.definedNames });

            });
                   }
    }
    // Save FlexSheet to xlsx file.

    save() {
        //debugger;
        let fileName;
        if (!!this.state.fileName) {
            fileName = this.state.fileName;
        }
        else {
            fileName = "FlexSheet.xlsx";
        }

        //this.state.flex.saveAsync(fileName);

        //let base64Excel = "na";
        this.state.flex.saveAsync("sks", function (base64) {
            //debugger;
                  fetch('http://localhost:62271/api/ExlData/',
                      {
                          
                     method: "POST",
                     headers:{'Content-Type': 'application/json'},
                     body: JSON.stringify({ excelName: fileName , excel: base64})
                 })
                 .then((res) => {
                     console.log(res)
                     alert('saved');
                 })
             document.getElementById('txtBase64').value = base64;
             //console.log(JSON.stringify({ excelName: fileName , excel: base64}));
         }, function (reason) {
             console.log('The reason of save failure is ' + reason);
         });

     



    }

    //saveSheet() {
    //   var fileName = "FlexSheet.xlsx";
    //    //debugger;
    //    var sheet = this.state.flex;
    //    sheet.saveAsync(null, (base64) => {
    //        fetch('http://localhost:62271/api/ExlData/',
    //            {
    //                method: "POST",
    //                headers: { 'Content-Type': 'application/json' },
    //                body: JSON.stringify({ excelName: fileName, excel: base64 })
    //            })
    //            .then((res) => {
    //                console.log(res)
    //            })

    //        //alert('saved');
    //        //console.log(base64);
    //    })
    //}
    setFileName(name) {
        this.setState({
            fileName: name.target.value
        });

    }

}
