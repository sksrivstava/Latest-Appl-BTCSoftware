"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("react");
var react_router_1 = require("react-router");
var Layout_1 = require("./components/Layout");
var Home_1 = require("./components/Home");
var Sheetfile_1 = require("./components/Sheetfile");
//import Templateform from './components/Templateform';
//import { Store } from "./Action/Store";
//import { Provider } from 'react-redux';
require("./custom.css");
exports.default = (function () { return (
//<Provider store={Store}>
React.createElement(Layout_1.default, null,
    React.createElement(react_router_1.Route, { exact: true, path: '/', component: Home_1.default }),
    React.createElement(react_router_1.Route, { path: '/Spreadsheet', component: Sheetfile_1.default }))
//</Provider>
); });
//# sourceMappingURL=App.js.map