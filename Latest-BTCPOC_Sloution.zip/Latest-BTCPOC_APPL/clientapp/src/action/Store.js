import { reducers } from "../Reducer/index";

import { applyMiddleware, compose, createStore } from 'redux';
import thunk from 'redux-thunk';




export const Store = createStore(
    reducers,
  compose(
    applyMiddleware(thunk)
    //  window._REDUX_DEVTOOLS_EXTENSION_ && Window._REDUX_DEVTOOLS_EXTENSION_()
  )
);