import axios from "axios";

const baseurl = "http://localhost:53677/api/";
export default {
  dTemplate(url = baseurl + "ExlData/") {
    return {
      fetchall: () => axios.get(url),
      fetchByid: (id) => axios.get(url + id),
      create: (newRecord) => axios.post(url + "AddTemplate", newRecord),
      update: (updateRecord) => axios.put(url + "updatetemplate", updateRecord),
      delete: (id) => axios.delete(url + "deleteTemplate=" + id),
    };
  },
};
