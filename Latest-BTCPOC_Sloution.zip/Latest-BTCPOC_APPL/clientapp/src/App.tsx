import * as React from 'react';
import { Route } from 'react-router';

import Layout from './components/Layout';
import Home from './components/Home';
import Sheetfile from './components/Sheetfile';
//import Templateform from './components/Templateform';
//import { Store } from "./Action/Store";
//import { Provider } from 'react-redux';

import './custom.css'

export default () => (
    //<Provider store={Store}>

    <Layout>
        <Route exact path='/' component={Home} />
        <Route path='/Spreadsheet' component={Sheetfile} />
     
    </Layout>
 //</Provider>
);
